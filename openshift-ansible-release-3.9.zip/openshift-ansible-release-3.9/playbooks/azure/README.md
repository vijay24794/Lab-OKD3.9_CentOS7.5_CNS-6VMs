The playbooks and tasks under this directory are not supported for end-customer
use.
