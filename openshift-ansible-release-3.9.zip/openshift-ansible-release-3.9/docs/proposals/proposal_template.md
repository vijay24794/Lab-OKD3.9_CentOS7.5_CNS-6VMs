# Proposal Title

## Description
<Short introduction>

## Rationale
<Summary of main points of Design>

## Design
<Main content goes here>

## Checklist
* Item 1
* Item 2
* Item 3

## User Story
As a developer on OpenShift-Ansible,
I want ...
so that ...

## Acceptance Criteria
* Verify that ...
* Verify that ...
* Verify that ...

## References
* Link
* Link
* Link
